plugins {
    id("com.android.application") version "8.7.3"
    id("org.jetbrains.kotlin.android") version "2.1.0"
}

android {
    namespace = "ch.leico.alveole"
    compileSdk = 35

    defaultConfig {
        applicationId = "ch.leico.alveole"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "0.4"
    }

    // Clé fixe : les mises à jour s'installent par-dessus sans perdre les mots appris
    signingConfigs {
        create("perso") {
            storeFile = file("alveole.keystore")
            storePassword = "alveole"
            keyAlias = "alveole"
            keyPassword = "alveole"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("perso")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
