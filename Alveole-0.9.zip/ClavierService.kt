package ch.leico.alveole

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class ClavierService : InputMethodService() {

    private lateinit var correcteur: Correcteur
    private var vue: ClavierView? = null
    private val mot = StringBuilder()

    private var corrigerActif = true
    /** Barre de propositions : partout sauf dans les mots de passe */
    private var suggestionsActives = true
    private var vibrations = true
    private var pointRaccourci = true
    /** 0 = lente, 1 = moyenne, 2 = rapide */
    var vitesseEffacement = 1
        private set
    /** 0 = les deux espaces, 1 = gauche, 2 = droite, 3 = désactivé */
    var curseurEspace = 0
        private set

    /** Mot précédent, validé par un espace : (tapé, affiché). Sert à corriger un espace mal placé. */
    private var precedent: Pair<String, String>? = null
    /** Dernière correction auto : (texte inséré, texte tapé). Retour arrière = annuler. */
    private var annulable: Pair<String, String>? = null
    /** Mot remis après annulation : s'il est validé tel quel, on l'apprend. */
    private var restaure: String? = null
    private var ignorerEspace = false
    private val supprimes = ArrayDeque<String>()
    private var dernierShift = 0L

    var shift = 0
        private set
    /** 0 = lettres, 1 = chiffres, 2 = symboles spéciaux, 3 = emojis */
    var couche = 0
        private set
    var suggestions: List<String> = emptyList()
        private set
    var indexCorrection = -1
        private set
    val vibrationsActives: Boolean
        get() = vibrations

    override fun onCreate() {
        super.onCreate()
        correcteur = Correcteur.obtenir(this)
    }

    override fun onCreateInputView(): View {
        val v = ClavierView(this, this)
        vue = v
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val prefs = getSharedPreferences("alveole", Context.MODE_PRIVATE)
        vibrations = prefs.getBoolean("vibrations", true)
        pointRaccourci = prefs.getBoolean("point", true)
        vitesseEffacement = prefs.getInt("vitesseEffacement", 1)
        curseurEspace = prefs.getInt("curseurEspace", 0)
        val classe = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        val motDePasse = classe == InputType.TYPE_CLASS_TEXT && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)
        suggestionsActives = classe == InputType.TYPE_CLASS_TEXT && !motDePasse
        // Pas de correction automatique dans les adresses mail / web (les propositions restent)
        val sansCorrection = classe != InputType.TYPE_CLASS_TEXT || motDePasse ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        corrigerActif = prefs.getBoolean("correction", true) && !sansCorrection
        val numerique = classe == InputType.TYPE_CLASS_NUMBER ||
            classe == InputType.TYPE_CLASS_PHONE ||
            classe == InputType.TYPE_CLASS_DATETIME
        couche = if (numerique) 1 else 0
        mot.clear()
        precedent = null
        annulable = null
        restaure = null
        ignorerEspace = false
        supprimes.clear()
        shift = 0
        majAuto()
        majSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        mot.clear()
        suggestions = emptyList()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // L'utilisateur a touché ailleurs dans le texte : on abandonne le mot en cours.
        if (mot.isNotEmpty() && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            mot.clear()
            currentInputConnection?.finishComposingText()
            precedent = null
            annulable = null
            majSuggestions()
        }
    }

    // ---------------------------------------------------------------- saisie

    /** casse : 1 = majuscule forcée (glisser en haut), -1 = minuscule forcée (glisser en bas), 0 = auto */
    fun caractere(brut: String, casse: Int = 0) {
        val ic = currentInputConnection ?: return
        if (brut.isEmpty()) return
        var s = brut
        val estLettre = s.length == 1 && s[0].isLetter()
        if (estLettre) {
            val maj = casse == 1 || (casse == 0 && shift > 0)
            s = if (maj) s.uppercase() else s.lowercase()
        }
        val c = s[0]
        if (estLettre || ((c == '\'' || c == '-') && s.length == 1 && mot.isNotEmpty())) {
            ignorerEspace = false
            annulable = null
            mot.append(s)
            ic.setComposingText(mot, 1)
            if (estLettre && shift == 1) shift = 0
            majSuggestions()
            vue?.invalidate()
        } else {
            valider(s)
        }
    }

    /** Valide le mot en cours (corrigé) suivi du séparateur. */
    private fun valider(sep: String) {
        val ic = currentInputConnection ?: return

        if (mot.isEmpty()) {
            if (sep == " " && ignorerEspace) {
                ignorerEspace = false
                return
            }
            ignorerEspace = false
            precedent = null
            annulable = null
            // Raccourci « . » : double espace = point + espace
            if (sep == " " && pointRaccourci) {
                val avant = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                if (avant.length == 2 && avant[1] == ' ' && avant[0].isLetterOrDigit()) {
                    ic.beginBatchEdit()
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText(". ", 1)
                    ic.endBatchEdit()
                    finCommit()
                    return
                }
            }
            // « salut ,» → « salut, »
            if (sep == "," || sep == ".") {
                val avant = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                if (avant.length == 2 && avant[1] == ' ' && avant[0].isLetter()) {
                    ic.beginBatchEdit()
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText("$sep ", 1)
                    ic.endBatchEdit()
                    ignorerEspace = true
                    finCommit()
                    return
                }
            }
            ic.commitText(sep, 1)
            finCommit()
            return
        }

        val orig = mot.toString()
        val avantMot = motPrecedent(orig.length)
        mot.clear()
        ignorerEspace = false

        // Mot remis après une annulation et validé tel quel : on l'apprend, sans corriger.
        if (restaure != null && restaure == orig) {
            correcteur.apprendre(orig)
            restaure = null
            ic.commitText(orig + sep, 1)
            annulable = null
            precedent = if (sep == " ") orig to orig else null
            finCommit()
            return
        }
        restaure = null

        // Espace mal placé avec le mot d'avant ?
        val p = precedent
        if (corrigerActif && p != null) {
            val attendu = p.second + " " + orig
            val avant = ic.getTextBeforeCursor(attendu.length, 0)?.toString()
            if (avant == attendu) {
                val paire = correcteur.corrigerPaire(p.first, orig)
                if (paire != null) {
                    ic.beginBatchEdit()
                    ic.setComposingText("", 1)
                    ic.deleteSurroundingText(p.second.length + 1, 0)
                    ic.commitText(paire + sep, 1)
                    ic.endBatchEdit()
                    annulable = (paire + sep) to (p.first + " " + orig)
                    precedent = null
                    finCommit()
                    return
                }
            }
        }

        val affiche = if (corrigerActif) correcteur.corriger(orig) else orig
        if (suggestionsActives) correcteur.apprendreSuite(avantMot, affiche.substringAfterLast(' '))
        ic.commitText(affiche + sep, 1)
        annulable = if (affiche != orig) (affiche + sep) to orig else null
        precedent = if (sep == " ") orig to affiche else null
        finCommit()
    }

    fun supprimer() {
        val ic = currentInputConnection ?: return
        ignorerEspace = false
        if (mot.isNotEmpty()) {
            mot.deleteCharAt(mot.length - 1)
            ic.setComposingText(mot, 1)
            annulable = null
            majSuggestions()
            vue?.invalidate()
            return
        }
        val a = annulable
        annulable = null
        precedent = null
        if (a != null) {
            val avant = ic.getTextBeforeCursor(a.first.length, 0)?.toString()
            if (avant == a.first) {
                // Annuler la correction : on remet exactement ce qui avait été tapé.
                ic.beginBatchEdit()
                ic.deleteSurroundingText(a.first.length, 0)
                if (a.second.contains(' ')) {
                    ic.commitText(a.second, 1)
                } else {
                    mot.append(a.second)
                    ic.setComposingText(mot, 1)
                    restaure = a.second
                }
                ic.endBatchEdit()
                majSuggestions()
                vue?.invalidate()
                return
            }
        }
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        finCommit()
    }

    fun supprimerMot() {
        val ic = currentInputConnection ?: return
        annulable = null
        precedent = null
        ignorerEspace = false
        if (mot.isNotEmpty()) {
            garder(mot.toString())
            mot.clear()
            ic.setComposingText("", 1)
            finCommit()
            return
        }
        val avant = ic.getTextBeforeCursor(80, 0)?.toString() ?: return
        val m = Regex("\\S+\\s*$").find(avant) ?: Regex("\\s+$").find(avant) ?: return
        ic.deleteSurroundingText(m.value.length, 0)
        garder(m.value)
        finCommit()
    }

    // ---- Effacer en glissant (comme un curseur) ----
    private val effaces = ArrayList<String>()

    fun effacementDebut() {
        val ic = currentInputConnection ?: return
        if (mot.isNotEmpty()) {
            ic.finishComposingText()
            mot.clear()
        }
        annulable = null
        precedent = null
        ignorerEspace = false
        restaure = null
        effaces.clear()
    }

    /** n = nombre de caractères effacés pendant ce geste (augmente vers la gauche, diminue vers la droite). */
    fun effacementAller(n: Int) {
        val ic = currentInputConnection ?: return
        var change = false
        while (effaces.size < n) {
            val avant = ic.getTextBeforeCursor(2, 0)?.toString() ?: break
            if (avant.isEmpty()) break
            val longueur = if (avant.length == 2 && Character.isSurrogatePair(avant[0], avant[1])) 2 else 1
            effaces.add(avant.takeLast(longueur))
            ic.deleteSurroundingText(longueur, 0)
            change = true
        }
        while (effaces.size > n) {
            ic.commitText(effaces.removeAt(effaces.size - 1), 1)
            change = true
        }
        if (change && vibrations) vue?.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
    }

    fun effacementFin() {
        if (effaces.isNotEmpty()) garder(effaces.reversed().joinToString(""))
        effaces.clear()
        finCommit()
    }

    private fun garder(s: String) {
        supprimes.addLast(s)
        if (supprimes.size > 30) supprimes.removeFirst()
    }

    fun restaurerMot() {
        val ic = currentInputConnection ?: return
        val s = supprimes.removeLastOrNull() ?: return
        if (mot.isNotEmpty()) {
            ic.finishComposingText()
            mot.clear()
        }
        ic.commitText(s, 1)
        annulable = null
        precedent = null
        finCommit()
    }

    fun deplacerCurseur(n: Int) {
        if (n == 0) return
        if (mot.isNotEmpty()) {
            currentInputConnection?.finishComposingText()
            mot.clear()
            majSuggestions()
        }
        precedent = null
        annulable = null
        val code = if (n < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        repeat(kotlin.math.abs(n)) { sendDownUpKeyEvents(code) }
    }

    fun entree() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        if (mot.isNotEmpty()) valider("")
        precedent = null
        annulable = null
        val options = info?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val pasAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (info != null && !pasAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendKeyChar('\n')
        }
        finCommit()
    }

    fun basculerShift() {
        val maintenant = System.currentTimeMillis()
        shift = when {
            shift == 2 -> 0
            shift == 1 && maintenant - dernierShift < 350 -> 2
            shift == 1 -> 0
            else -> 1
        }
        dernierShift = maintenant
        vue?.invalidate()
    }

    private var dernierChangementCouche = 0L

    /** Anti double-appui : un 2e appui à moins de 0,3 s après un changement de page est ignoré. */
    private fun changementTropRapide(): Boolean {
        val maintenant = android.os.SystemClock.uptimeMillis()
        if (maintenant - dernierChangementCouche < 300) return true
        dernierChangementCouche = maintenant
        return false
    }

    fun basculerCouche() {
        if (changementTropRapide()) return
        couche = if (couche == 0) 1 else 0
        vue?.invalidate()
    }

    /** Glisser vers le haut sur la touche 123 / ABC : lettres → emojis, chiffres → symboles spéciaux. */
    fun coucheHaut() {
        if (changementTropRapide()) return
        couche = when (couche) {
            0 -> 3
            1 -> 2
            else -> 1
        }
        vue?.invalidate()
    }

    fun fermerEmojis() {
        couche = 0
        vue?.invalidate()
    }

    // ---- Emojis ----
    fun emojisRecents(): List<String> {
        val brut = getSharedPreferences("alveole", Context.MODE_PRIVATE).getString("recents", "") ?: ""
        return if (brut.isEmpty()) emptyList() else brut.split('\u0001')
    }

    fun emoji(e: String) {
        val ic = currentInputConnection ?: return
        if (mot.isNotEmpty()) valider("")
        ic.commitText(e, 1)
        annulable = null
        precedent = null
        val liste = ArrayList(emojisRecents())
        liste.remove(e)
        liste.add(0, e)
        while (liste.size > 24) liste.removeAt(liste.size - 1)
        getSharedPreferences("alveole", Context.MODE_PRIVATE).edit()
            .putString("recents", liste.joinToString("\u0001")).apply()
        finCommit()
    }

    fun choisirSuggestion(i: Int) {
        val s = suggestions.getOrNull(i) ?: return
        val ic = currentInputConnection ?: return
        val orig = mot.toString()
        correcteur.apprendreSuite(motPrecedent(orig.length), s)
        mot.clear()
        ic.commitText("$s ", 1)
        // Choisir exactement ce qu'on a tapé = « ce mot est correct, retiens-le »
        if (s == orig && i != indexCorrection) correcteur.apprendre(orig)
        annulable = null
        precedent = if (s.contains(' ')) null else s to s
        restaure = null
        finCommit()
    }

    // ---------------------------------------------------------------- état

    private fun finCommit() {
        majAuto()
        majSuggestions()
        vue?.invalidate()
    }

    /** Majuscule automatique en début de phrase. */
    private fun majAuto() {
        if (shift == 2 || mot.isNotEmpty()) return
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val modes = if (corrigerActif) InputType.TYPE_TEXT_FLAG_CAP_SENTENCES else info.inputType
        shift = if (modes != 0 && ic.getCursorCapsMode(modes) != 0) 1 else 0
    }

    /** Mot juste avant celui qu'on tape (null en début de phrase). */
    private fun motPrecedent(longueurEnCours: Int): String? {
        val ic = currentInputConnection ?: return null
        val avant = ic.getTextBeforeCursor(60 + longueurEnCours, 0)?.toString() ?: return null
        val texte = avant.dropLast(minOf(longueurEnCours, avant.length))
        return Regex("([\\p{L}'’-]+)\\s+$").find(texte)?.groupValues?.get(1)
    }

    private fun majSuggestions() {
        indexCorrection = -1
        if (!suggestionsActives || !correcteur.pret) {
            suggestions = emptyList()
            return
        }
        if (mot.isEmpty()) {
            // Prédiction du mot suivant (apprise sur ta façon d'écrire, tout reste sur le téléphone)
            val liste = correcteur.predire(motPrecedent(0), 4)
            suggestions = liste.map { if (shift > 0) it.replaceFirstChar { c -> c.uppercaseChar() } else it }
            if (suggestions.size >= 2) {
                val l = ArrayList(suggestions)
                val premier = l.removeAt(0)
                l.add(1, premier)
                suggestions = l
                indexCorrection = 1
            }
            return
        }
        val orig = mot.toString()
        val liste = ArrayList<String>()
        val corr = if (corrigerActif) correcteur.corrigerRapide(orig) else orig
        if (corr != orig) {
            liste.add(orig)
            liste.add(corr)
            indexCorrection = 1
        }
        for (s in correcteur.suggestions(orig, 5)) {
            if (liste.size >= 4) break
            if (s != orig && s !in liste) liste.add(s)
        }
        if (indexCorrection < 0 && liste.size >= 2) {
            // la meilleure proposition au milieu, comme d'habitude
            val premier = liste.removeAt(0)
            liste.add(1, premier)
            indexCorrection = 1
        }
        suggestions = liste
    }
}
