package ch.leico.alveole

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@SuppressLint("ViewConstructor")
class ClavierView(context: Context, private val service: ClavierService) : View(context) {

    enum class Type { CAR, ESPACE, SHIFT, SUPPR, ENTREE, COUCHE, ACTION, EMOJI, DECOR }

    /**
     * Une alvéole.
     *  - haut  : zone foncée (simple appui)
     *  - clair : zone claire (glisser vers le haut) ; vide = touche d'une seule couleur
     *  - bis   : choix proposés en maintenant le doigt ; bisDefaut = case sélectionnée d'office
     */
    class Touche(
        val type: Type,
        val haut: String = "",
        val clair: String = "",
        val bis: List<String> = emptyList(),
        val bisDefaut: Int = 0
    ) {
        var cx = 0f
        var cy = 0f
        val forme = Path()
    }

    class Couche(val rangees: List<List<Touche>>) {
        val gauche = Touche(Type.SHIFT)
        val droite = Touche(Type.SUPPR)
        val toutes: List<Touche> = rangees.flatten() + listOf(gauche, droite)
    }

    companion object {
        private val SQRT3 = sqrt(3f)

        private fun car(s: String) = Touche(Type.CAR, s)
        private fun deux(fonce: String, clair: String, bis: List<String> = emptyList(), defaut: Int = 0) =
            Touche(Type.CAR, fonce, clair, bis, defaut)
        private fun rangee(s: String) = s.split(' ').map { car(it) }

        /** Lettre : appui long = accents, l'accent le plus courant sélectionné d'office */
        private fun lettre(s: String): Touche {
            val (liste, defaut) = when (s) {
                "a" -> listOf("æ", "à", "â", "ä") to 1
                "e" -> listOf("è", "é", "ê", "ë") to 1
                "i" -> listOf("ï", "î") to 1
                "o" -> listOf("ö", "ô", "œ") to 1
                "u" -> listOf("û", "ù", "ü") to 1
                "c" -> listOf("ç") to 0
                "y" -> listOf("ÿ") to 0
                "n" -> listOf("ñ") to 0
                else -> emptyList<String>() to 0
            }
            return Touche(Type.CAR, s, "", liste, defaut)
        }
        private fun lettres(s: String) = s.split(' ').map { lettre(it) }

        // « . » foncé, « , » clair (glisser en haut), maintenir = « : » (ou « ; »)
        private fun ponctGauche() = deux(".", ",", listOf(":", ";"), 0)
        // « ? » foncé, « ! » clair, maintenir = « ' » (ou « " »)
        private fun ponctDroite() = deux("?", "!", listOf("\"", "'"), 1)

        // Emojis par catégorie (icône de l'onglet, titre, liste)
        val CATEGORIES: List<Triple<String, String, List<String>>> = listOf(
            Triple("😀", "ÉMOTICÔNES ET PERSONNES",
                ("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥳 😏 " +
                    "😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 " +
                    "🤥 😶 😐 😑 😬 🙄 😯 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 💩 👻 💀 👽 🤖").split(' ')),
            Triple("👍", "GESTES",
                "👍 👎 👌 🤌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 👋 🤝 🙏 💪 👏 🙌 👐 🤲 ✍️ 🤷 🤦 🙋 🙈 🙉 🙊".split(' ')),
            Triple("❤️", "CŒURS ET SYMBOLES",
                "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 🔥 ✨ ⭐ 🌟 💯 ✅ ❌ ⚠️ ❓ ❗ 💤 💬 👀 🎉".split(' ')),
            Triple("🐱", "ANIMAUX ET NATURE",
                "🐱 🐈 😺 😸 😹 😻 🙀 😿 😾 🐶 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦆 🦉 🐴 🦄 🐝 🦋 🐢 🐍 🐙 🐟 🐬 🐳 🌸 🌹 🌻 🌲 🍀 🍁 🌙 ☀️ ⛅ 🌧️ ❄️ 🌈".split(' ')),
            Triple("🍕", "NOURRITURE",
                "🍕 🍔 🍟 🌭 🥪 🌮 🍝 🍜 🍣 🍦 🍩 🍪 🎂 🍫 🍿 🍺 🍻 🍷 🥂 ☕ 🍎 🍌 🍓 🍉 🍇 🧀 🥐 🥖 🍳 🥩".split(' ')),
            Triple("⚽", "ACTIVITÉS ET OBJETS",
                "⚽ 🏀 🎮 🕹️ 🎧 🎵 🎁 🎄 🚗 🏎️ ✈️ 🏠 💻 📱 ⌚ 📷 💡 🔧 🛠️ 💰 💸 📅 ⏰ 🎬 📺 🔋 🔑 🎯 🏆 🚀".split(' '))
        )
    }

    // ---------------------------------------------------------------- les trois pages

    private val pageLettres = Couche(
        listOf(
            lettres("w e t z i o"),
            lettres("q a r g u l p"),
            listOf(ponctGauche(), Touche(Type.ESPACE, "g"), lettre("f"), lettre("h"), Touche(Type.ESPACE, "d"), ponctDroite()),
            lettres("y s d n m j k"),
            lettres("x c v b") + listOf(Touche(Type.COUCHE, "123", "☺"), Touche(Type.ENTREE))
        )
    )

    // Copie de ta photo Typewise
    private val pageChiffres = Couche(
        listOf(
            listOf(deux("^", "~"), car("1"), car("2"), car("3"), car("4"), deux("<", ">", listOf("«", "»"), 0)),
            listOf(
                deux("€", "$", listOf("£", "¥", "¢"), 0), deux("+", "=", listOf("±"), 0),
                car("5"), car("6"), car("7"),
                deux("(", "[", listOf("{"), 0), deux(")", "]", listOf("}"), 0)
            ),
            listOf(ponctGauche(), Touche(Type.ESPACE, "g"), car("8"), car("9"), Touche(Type.ESPACE, "d"), ponctDroite()),
            listOf(
                deux("§", "°"), deux("-", "–"), car("_"), car("0"),
                deux("*", "`"), deux("/", "|", listOf("\\"), 0), deux("¿", "¡")
            ),
            rangee("& % @ #") + listOf(Touche(Type.COUCHE, "ABC", "¥?±"), Touche(Type.ENTREE))
        )
    )

    private val pageSpeciaux = Couche(
        listOf(
            rangee("¥ £ ¢ ₿ © ®"),
            rangee("™ ± × ÷ ≠ ≈ ∞"),
            listOf(ponctGauche(), Touche(Type.ESPACE, "g"), car("√"), car("π"), Touche(Type.ESPACE, "d"), ponctDroite()),
            rangee("• … † ‰ ¶ ‹ ›"),
            rangee("¹ ² ³ ½") + listOf(Touche(Type.COUCHE, "ABC", "123"), Touche(Type.ENTREE))
        )
    )

    // ---------------------------------------------------------------- page paysage
    // Clavier coupé en deux : moitié gauche collée au bord gauche (T R F D V à l'intérieur),
    // moitié droite collée au bord droit (Z G H N B à l'intérieur), chiffres + symboles au milieu.

    /** bloc : 0 = moitié gauche, 1 = milieu, 2 = moitié droite ; col en largeurs d'alvéole */
    private class Place(val t: Touche, val rang: Int, val bloc: Int, val col: Float)

    private val placesPaysage = ArrayList<Place>()

    private var pagePaysage: Couche = run {
        fun g(rang: Int, col: Float, t: Touche) { placesPaysage.add(Place(t, rang, 0, col)) }
        fun m(rang: Int, col: Float, t: Touche) { placesPaysage.add(Place(t, rang, 1, col)) }
        fun d(rang: Int, col: Float, t: Touche) { placesPaysage.add(Place(t, rang, 2, col)) }
        // moitié gauche
        g(0, 1f, lettre("w")); g(0, 2f, lettre("e")); g(0, 3f, lettre("t"))
        g(1, 0.5f, lettre("q")); g(1, 1.5f, lettre("a")); g(1, 2.5f, lettre("r"))
        g(2, 1f, ponctGauche()); g(2, 2f, Touche(Type.ESPACE, "g")); g(2, 3f, lettre("f"))
        g(3, 0.5f, lettre("y")); g(3, 1.5f, lettre("s")); g(3, 2.5f, lettre("d"))
        g(4, 1f, lettre("x")); g(4, 2f, lettre("c")); g(4, 3f, lettre("v"))
        // moitié droite (mêmes colonnes qu'en portrait)
        d(0, 4f, lettre("z")); d(0, 5f, lettre("i")); d(0, 6f, lettre("o"))
        d(1, 3.5f, lettre("g")); d(1, 4.5f, lettre("u")); d(1, 5.5f, lettre("l")); d(1, 6.5f, lettre("p"))
        d(2, 4f, lettre("h")); d(2, 5f, Touche(Type.ESPACE, "d")); d(2, 6f, ponctDroite())
        d(3, 3.5f, lettre("n")); d(3, 4.5f, lettre("m")); d(3, 5.5f, lettre("j")); d(3, 6.5f, lettre("k"))
        d(4, 4f, lettre("b")); d(4, 5f, Touche(Type.COUCHE, "123", "☺")); d(4, 6f, Touche(Type.ENTREE))
        // milieu : pyramide inversée 1234 / 567 / 89 / 0, symboles autour
        m(0, 1f, car("1")); m(0, 2f, car("2")); m(0, 3f, car("3")); m(0, 4f, car("4"))
        m(1, 0.5f, deux("-", "_", listOf("–", "—"), 0))
        m(1, 1.5f, car("5")); m(1, 2.5f, car("6")); m(1, 3.5f, car("7"))
        m(1, 4.5f, deux("+", "=", listOf("±"), 0))
        m(2, 1f, deux("(", "[", listOf("{", "<"), 0)); m(2, 2f, car("8")); m(2, 3f, car("9"))
        m(2, 4f, deux(")", "]", listOf("}", ">"), 0))
        m(3, 0.5f, deux("@", "#")); m(3, 1.5f, deux("€", "$", listOf("£", "¥", "¢"), 0))
        m(3, 2.5f, car("0"))
        m(3, 3.5f, deux("%", "&")); m(3, 4.5f, deux("/", "|", listOf("\\"), 0))
        m(4, 1f, deux("*", "^", listOf("~"), 0)); m(4, 2f, deux(":", ";"))
        m(4, 3f, deux("«", "»")); m(4, 4f, deux("°", "§"))
        Couche(listOf(placesPaysage.map { it.t }))
    }

    private var paysage = false

    /** Colonne d'édition à côté de la moitié gauche (une par rangée) */
    private val ACTIONS = listOf("Tout", "Couper", "Copier", "Coller", "↶")

    private fun placerPaysage(largeur: Float) {
        // Une seule ruche continue sur toute la largeur
        val C = maxOf(14, (largeur / w).toInt())
        val S = C - 7          // décalage de la moitié droite
        val M = (C - 5) / 2    // début du bloc chiffres
        val x0p = (largeur - C * w) / 2f
        val extras = ArrayList<Place>()
        for (rang in 0 until 5) {
            val decale = rang % 2 == 0
            val positions = if (decale) (1 until C).map { it.toFloat() } else (0 until C).map { it + 0.5f }
            for (p in positions) {
                val pris = if (decale) p <= 3f || p >= S + 4f || (p >= M + 1f && p <= M + 4f)
                else p <= 2.5f || p >= S + 3.5f || (p >= M + 0.5f && p <= M + 4.5f)
                if (pris) continue
                val aGauche = if (decale) p == 4f else p == 3.5f
                val aDroite = if (decale) p == S + 3f else p == S + 2.5f
                val t = when {
                    aGauche -> Touche(Type.ACTION, ACTIONS[rang])
                    aDroite -> Touche(Type.EMOJI, rang.toString())
                    else -> Touche(Type.DECOR)
                }
                extras.add(Place(t, rang, -1, p))
            }
        }
        val origines = floatArrayOf(0f, M.toFloat(), S.toFloat())
        val toutes = placesPaysage + extras
        for (pl in toutes) {
            val colGlobale = if (pl.bloc < 0) pl.col else origines[pl.bloc] + pl.col
            pl.t.cx = x0p + colGlobale * w
            pl.t.cy = barre + marge + r * ky + pl.rang * 1.5f * r * ky
            hexagone(pl.t.forme, pl.t.cx, pl.t.cy, r * 0.965f)
        }
        val nouvelle = Couche(listOf(toutes.map { it.t }))
        val y2 = barre + marge + 4f * r * ky
        nouvelle.gauche.cx = x0p + w * 0.3f
        nouvelle.gauche.cy = y2
        nouvelle.droite.cx = x0p + C * w - w * 0.3f
        nouvelle.droite.cy = y2
        pagePaysage = nouvelle
    }

    /** Emojis de la colonne de droite en paysage : tes récents, sinon des classiques */
    private fun emojiRapide(i: Int): String {
        val recents = service.emojisRecents()
        val defaut = listOf("😂", "❤️", "👍", "😊", "🙏")
        return recents.getOrNull(i) ?: defaut[i % defaut.size]
    }

    private val dp = resources.displayMetrics.density
    private val barre = 34 * dp
    private val marge = 1 * dp
    /** Alvéoles un peu étirées en hauteur pour remplir l'espace (1 = hexagone parfait) */
    private val ky = 1f
    private val NB_PROPOSITIONS = 4
    private var w = 0f
    private var r = 0f
    private var x0 = 0f

    // Couleurs relevées sur ta capture Typewise
    private val cFond = Color.parseColor("#000000")
    private val cTouche = Color.parseColor("#393939")
    private val cClair = Color.parseColor("#555555")
    private val cPresse = Color.parseColor("#666666")
    private val cEspace = Color.parseColor("#707070")
    private val cEspacePresse = Color.parseColor("#909090")
    private val cBleu = Color.parseColor("#3C61E3")
    private val cBleuPresse = Color.parseColor("#6A86EC")
    private val cGris = Color.parseColor("#B0B0B4")
    private val cOr = Color.parseColor("#C9B793")
    private val cGrisFonce = Color.parseColor("#6A6A6E")
    private val cSep = Color.parseColor("#555558")
    private val cBulle = Color.parseColor("#4E4E52")
    private val cDecor = Color.parseColor("#141414")
    private val cAction = Color.parseColor("#262626")
    private val rect = RectF()

    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pTexte = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val pTrait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val pBarre = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
    }
    private val pSep = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#555558")
        strokeWidth = 1.5f * dp
    }
    private val normal = Typeface.create("sans-serif", Typeface.NORMAL)
    private val gras = Typeface.create("sans-serif", Typeface.BOLD)

    // ---------------------------------------------------------------- géométrie

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val largeur = MeasureSpec.getSize(widthMeasureSpec)
        calculer(largeur.toFloat(), resources.displayMetrics.heightPixels.toFloat())
        setMeasuredDimension(largeur, (barre + 2 * marge + 8 * r * ky).toInt())
    }

    private fun calculer(largeur: Float, ecran: Float) {
        paysage = largeur > ecran * 1.2f
        val rMax = (ecran * (if (paysage) 0.55f else 0.42f) - barre - 2 * marge) / (8f * ky)
        // en paysage il faut la place pour 2 moitiés (3,5 + 3,5) + le milieu (5) + un peu d'air
        r = minOf(largeur / (if (paysage) 14f else 7f) / SQRT3, rMax)
        w = r * SQRT3
        x0 = (largeur - 7 * w) / 2f
        // coins à peine arrondis, alvéoles serrées comme sur Typewise
        pFill.pathEffect = CornerPathEffect(r * 0.09f)
        pTrait.strokeWidth = r * 0.075f
        placer(pageLettres)
        placer(pageChiffres)
        placer(pageSpeciaux)
        placerPaysage(largeur)
    }

    private fun placer(c: Couche) {
        c.rangees.forEachIndexed { i, rangee ->
            val y = barre + marge + r * ky + i * 1.5f * r * ky
            val decale = rangee.size < 7
            rangee.forEachIndexed { j, t ->
                t.cx = x0 + if (decale) w * (j + 1) else w * (j + 0.5f)
                t.cy = y
                hexagone(t.forme, t.cx, t.cy, r * 0.965f)
            }
        }
        val y2 = barre + marge + 4f * r * ky
        c.gauche.cx = x0 + w * 0.3f
        c.gauche.cy = y2
        c.droite.cx = x0 + 7 * w - w * 0.3f
        c.droite.cy = y2
    }

    private fun hexagone(p: Path, cx: Float, cy: Float, rr: Float) {
        p.reset()
        for (k in 0 until 6) {
            val a = Math.toRadians(60.0 * k - 90.0)
            val x = cx + rr * cos(a).toFloat()
            val y = cy + rr * ky * sin(a).toFloat()
            if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun couche(): Couche = when (service.couche) {
        1 -> pageChiffres
        2 -> pageSpeciaux
        else -> if (paysage) pagePaysage else pageLettres
    }

    private fun trouver(x: Float, y: Float): Touche? {
        var meilleure: Touche? = null
        var dMin = Float.MAX_VALUE
        for (t in couche().toutes) {
            if (t.type == Type.DECOR) continue
            val dx = x - t.cx
            val dy = (y - t.cy) / ky
            val d = dx * dx + dy * dy
            if (d < dMin) {
                dMin = d
                meilleure = t
            }
        }
        // toucher dans un espace vide (entre les blocs en paysage) : rien
        if (dMin > (1.6f * r) * (1.6f * r)) return null
        return meilleure
    }

    private fun majuscules() = service.shift > 0 && service.couche == 0

    // ---------------------------------------------------------------- dessin

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(cFond)
        if (service.couche == 3) {
            dessinerEmojis(canvas)
            return
        }
        dessinerBarre(canvas)
        for (t in couche().toutes) dessinerTouche(canvas, t)
        for (d in doigts.values) dessinerBulle(canvas, d)
    }

    /** Largeur du bouton correction à gauche de la barre */
    private fun boutonCorr() = if (service.correctionVisible) 40 * dp else 0f

    private fun dessinerBarre(cv: Canvas) {
        val sugg = service.suggestions
        val b = boutonCorr()
        if (b > 0) {
            // « abc » doré = correction active ; gris barré = correction coupée
            val cx = b / 2f
            val cy = barre / 2f
            val actif = service.correctionActive
            pBarre.typeface = gras
            pBarre.textSize = 13 * dp
            pBarre.color = if (actif) cOr else cGrisFonce
            val m = pBarre.fontMetrics
            cv.drawText("abc", cx, cy - (m.ascent + m.descent) / 2f, pBarre)
            if (!actif) {
                pSep.color = cGrisFonce
                cv.drawLine(cx - 13 * dp, cy + 6 * dp, cx + 13 * dp, cy - 6 * dp, pSep)
                pSep.color = cSep
            }
            pBarre.color = Color.WHITE
        }
        val l = (width - b) / NB_PROPOSITIONS.toFloat()
        for (i in 0 until NB_PROPOSITIONS) {
            if (i > 0 || b > 0) cv.drawLine(b + l * i, barre * 0.25f, b + l * i, barre * 0.75f, pSep)
            var s = sugg.getOrNull(i) ?: continue
            if (i == service.slotAnnuler) s = "« $s »"
            pBarre.typeface = if (i == service.indexCorrection) gras else normal
            var taille = 18 * dp
            pBarre.textSize = taille
            while (pBarre.measureText(s) > l - 8 * dp && taille > 9 * dp) {
                taille -= dp
                pBarre.textSize = taille
            }
            val m = pBarre.fontMetrics
            cv.drawText(s, b + l * i + l / 2f, barre / 2f - (m.ascent + m.descent) / 2f, pBarre)
        }
    }

    private fun remplir(cv: Canvas, t: Touche, couleur: Int) {
        pFill.color = couleur
        cv.drawPath(t.forme, pFill)
    }

    /** Zone claire = haut de l'alvéole, jusqu'un peu au-dessus du milieu */
    private fun remplirHaut(cv: Canvas, t: Touche, couleur: Int) {
        cv.save()
        cv.clipRect(t.cx - r, t.cy - r * 1.2f, t.cx + r, t.cy - r * 0.08f)
        remplir(cv, t, couleur)
        cv.restore()
    }

    private fun texte(cv: Canvas, s: String, x: Float, y: Float, taille: Float, couleur: Int) {
        if (s.isEmpty()) return
        pTexte.textSize = taille
        pTexte.color = couleur
        val m = pTexte.fontMetrics
        cv.drawText(s, x, y - (m.ascent + m.descent) / 2f, pTexte)
    }

    private fun dessinerTouche(cv: Canvas, t: Touche) {
        val presse = t in pressees
        when (t.type) {
            Type.CAR -> {
                remplir(cv, t, if (presse) cPresse else cTouche)
                if (t.clair.isEmpty()) {
                    val s = if (majuscules()) t.haut.uppercase() else t.haut
                    val taille = if (t.haut[0].isLetter()) r * 0.8f else r * 0.7f
                    texte(cv, s, t.cx, t.cy, taille, Color.WHITE)
                } else {
                    if (!presse) remplirHaut(cv, t, cClair)
                    texte(cv, t.clair, t.cx, t.cy - r * 0.5f, r * 0.5f, Color.WHITE)
                    texte(cv, t.haut, t.cx, t.cy + r * 0.4f, r * 0.58f, Color.WHITE)
                    t.bis.getOrNull(t.bisDefaut)?.let {
                        texte(cv, it, t.cx + r * 0.42f, t.cy + r * 0.25f, r * 0.32f, Color.WHITE)
                    }
                }
            }
            Type.ESPACE -> remplir(cv, t, if (presse) cEspacePresse else cEspace)
            Type.ENTREE -> {
                remplir(cv, t, if (presse) cBleuPresse else cBleu)
                iconeEntree(cv, t.cx, t.cy)
            }
            Type.COUCHE -> {
                remplir(cv, t, if (presse) cPresse else cTouche)
                if (!presse) remplirHaut(cv, t, cClair)
                texte(cv, t.clair, t.cx, t.cy - r * 0.5f, r * 0.4f, Color.WHITE)
                texte(cv, t.haut, t.cx, t.cy + r * 0.4f, r * 0.42f, Color.WHITE)
            }
            Type.SHIFT -> iconeShift(cv, t.cx, t.cy, presse)
            Type.SUPPR -> iconeSuppr(cv, t.cx, t.cy, presse)
            Type.DECOR -> remplir(cv, t, cDecor)
            Type.ACTION -> {
                remplir(cv, t, if (presse) cPresse else cAction)
                texte(cv, t.haut, t.cx, t.cy, if (t.haut.length > 2) r * 0.3f else r * 0.6f, cOr)
            }
            Type.EMOJI -> {
                remplir(cv, t, if (presse) cPresse else cAction)
                texte(cv, emojiRapide(t.haut.toInt()), t.cx, t.cy, r * 0.6f, Color.WHITE)
            }
        }
    }

    /** Bulle au-dessus du doigt : le caractère en grand, ou le choix « bis » quand on maintient. */
    private fun dessinerBulle(cv: Canvas, d: Doigt) {
        val t = d.touche ?: return
        if (d.efface || t.type != Type.CAR) return
        val y = t.cy - 1.55f * r
        val h = r * 1.1f
        val popup = d.popup
        if (popup == null) {
            pFill.color = cBulle
            rect.set(t.cx - w * 0.42f, y - h / 2f, t.cx + w * 0.42f, y + h / 2f)
            cv.drawRoundRect(rect, r * 0.25f, r * 0.25f, pFill)
            texte(cv, if (majuscules()) t.haut.uppercase() else t.haut, t.cx, y, r * 0.85f, Color.WHITE)
            return
        }
        val (gauche, cell) = cellules(d, popup.size)
        pFill.color = cBulle
        rect.set(gauche, y - h / 2f, gauche + cell * popup.size, y + h / 2f)
        cv.drawRoundRect(rect, r * 0.25f, r * 0.25f, pFill)
        popup.forEachIndexed { i, s ->
            val cx = gauche + cell * (i + 0.5f)
            if (i == d.choix) {
                pFill.color = cBleu
                rect.set(cx - cell / 2f + 3 * dp, y - h / 2f + 3 * dp, cx + cell / 2f - 3 * dp, y + h / 2f - 3 * dp)
                cv.drawRoundRect(rect, r * 0.2f, r * 0.2f, pFill)
            }
            texte(cv, if (majuscules()) s.uppercase() else s, cx, y, r * 0.7f, Color.WHITE)
        }
    }

    private fun cellules(d: Doigt, n: Int): Pair<Float, Float> {
        val t = d.touche!!
        val cell = w * 0.85f
        val largeur = cell * n
        // la case proposée d'office tombe juste au-dessus du doigt
        val gauche = (t.cx - cell * (d.defaut + 0.5f)).coerceIn(0f, maxOf(0f, width - largeur))
        return gauche to cell
    }

    private fun halo(cv: Canvas, x: Float, y: Float) {
        pFill.color = cPresse
        cv.drawCircle(x, y, r * 0.5f, pFill)
    }

    private fun iconeShift(cv: Canvas, x: Float, y: Float, presse: Boolean) {
        if (presse) halo(cv, x, y)
        val s = r * 0.3f
        val p = Path().apply {
            moveTo(x, y - s)
            lineTo(x + s, y)
            lineTo(x + s * 0.45f, y)
            lineTo(x + s * 0.45f, y + s * 0.8f)
            lineTo(x - s * 0.45f, y + s * 0.8f)
            lineTo(x - s * 0.45f, y)
            lineTo(x - s, y)
            close()
        }
        if (service.shift > 0) {
            pFill.color = Color.WHITE
            cv.drawPath(p, pFill)
        } else {
            cv.drawPath(p, pTrait)
        }
        if (service.shift == 2) cv.drawLine(x - s * 0.6f, y + s * 1.3f, x + s * 0.6f, y + s * 1.3f, pTrait)
    }

    private fun iconeSuppr(cv: Canvas, x: Float, y: Float, presse: Boolean) {
        if (presse) halo(cv, x, y)
        val s = r * 0.3f
        val p = Path().apply {
            moveTo(x - s * 1.1f, y)
            lineTo(x - s * 0.45f, y - s * 0.7f)
            lineTo(x + s, y - s * 0.7f)
            lineTo(x + s, y + s * 0.7f)
            lineTo(x - s * 0.45f, y + s * 0.7f)
            close()
        }
        cv.drawPath(p, pTrait)
        cv.drawLine(x - s * 0.05f, y - s * 0.3f, x + s * 0.55f, y + s * 0.3f, pTrait)
        cv.drawLine(x - s * 0.05f, y + s * 0.3f, x + s * 0.55f, y - s * 0.3f, pTrait)
    }

    private fun iconeEntree(cv: Canvas, x: Float, y: Float) {
        val s = r * 0.32f
        val p = Path().apply {
            moveTo(x + s * 0.7f, y - s * 0.7f)
            lineTo(x + s * 0.7f, y + s * 0.25f)
            lineTo(x - s * 0.7f, y + s * 0.25f)
        }
        cv.drawPath(p, pTrait)
        cv.drawLine(x - s * 0.7f, y + s * 0.25f, x - s * 0.3f, y - s * 0.15f, pTrait)
        cv.drawLine(x - s * 0.7f, y + s * 0.25f, x - s * 0.3f, y + s * 0.65f, pTrait)
    }

    // ---------------------------------------------------------------- page emojis

    private class LigneEmoji(val titre: String?, val emojis: List<String>, val y: Float, val h: Float)

    private var defilement = 0f
    private var lignesEmoji: List<LigneEmoji> = emptyList()
    private val debutCategorie = ArrayList<Float>()

    private fun colonneDroite() = width - w * 1.05f
    private fun nbColonnes() = 8
    private fun celluleEmoji() = colonneDroite() / nbColonnes()

    private fun construireEmojis() {
        val cell = celluleEmoji()
        val res = ArrayList<LigneEmoji>()
        debutCategorie.clear()
        var y = 0f
        val sections = ArrayList<Pair<String, List<String>>>()
        val recents = service.emojisRecents()
        if (recents.isNotEmpty()) sections.add("RÉCENTS" to recents)
        for ((_, titre, liste) in CATEGORIES) sections.add(titre to liste)
        for ((titre, liste) in sections) {
            debutCategorie.add(y)
            res.add(LigneEmoji(titre, emptyList(), y, cell * 0.55f))
            y += cell * 0.55f
            for (bloc in liste.chunked(nbColonnes())) {
                res.add(LigneEmoji(null, bloc, y, cell))
                y += cell
            }
        }
        lignesEmoji = res
    }

    private fun hauteurEmojis() = lignesEmoji.lastOrNull()?.let { it.y + it.h } ?: 0f
    private fun zoneEmojis() = height - barre

    private fun dessinerEmojis(cv: Canvas) {
        construireEmojis()
        val maxDef = maxOf(0f, hauteurEmojis() - zoneEmojis())
        defilement = defilement.coerceIn(0f, maxDef)

        // Barre du haut : onglets des catégories
        val onglets = onglets()
        val l = width / onglets.size.toFloat()
        onglets.forEachIndexed { i, s ->
            texte(cv, s, l * i + l / 2f, barre / 2f, 20 * dp, Color.WHITE)
        }

        // Grille
        val cell = celluleEmoji()
        cv.save()
        cv.clipRect(0f, barre, colonneDroite(), height.toFloat())
        for (ligne in lignesEmoji) {
            val y = barre + ligne.y - defilement
            if (y + ligne.h < barre || y > height) continue
            if (ligne.titre != null) {
                pTexte.textAlign = Paint.Align.LEFT
                pTexte.typeface = gras
                texte(cv, ligne.titre, 10 * dp, y + ligne.h / 2f, 12 * dp, cGris)
                pTexte.textAlign = Paint.Align.CENTER
                pTexte.typeface = normal
            } else {
                ligne.emojis.forEachIndexed { i, e ->
                    texte(cv, e, cell * (i + 0.5f), y + ligne.h / 2f, cell * 0.62f, Color.WHITE)
                }
            }
        }
        cv.restore()

        // Colonne de droite : fermer, effacer, espace, entrée
        val boutons = boutonsEmoji()
        boutons.forEachIndexed { i, b ->
            val cx = colonneDroite() + (width - colonneDroite()) / 2f
            val cy = b
            when (i) {
                0 -> {
                    val s = r * 0.25f
                    cv.drawLine(cx - s, cy - s, cx + s, cy + s, pTrait)
                    cv.drawLine(cx - s, cy + s, cx + s, cy - s, pTrait)
                }
                1 -> iconeSuppr(cv, cx, cy, false)
                2 -> {
                    val s = r * 0.32f
                    val p = Path().apply {
                        moveTo(cx - s, cy - s * 0.3f)
                        lineTo(cx - s, cy + s * 0.3f)
                        lineTo(cx + s, cy + s * 0.3f)
                        lineTo(cx + s, cy - s * 0.3f)
                    }
                    cv.drawPath(p, pTrait)
                }
                3 -> {
                    pFill.color = cBleu
                    cv.drawCircle(cx, cy, r * 0.5f, pFill)
                    iconeEntree(cv, cx, cy)
                }
            }
        }
    }

    private fun onglets(): List<String> {
        val liste = ArrayList<String>()
        if (service.emojisRecents().isNotEmpty()) liste.add("🕘")
        for ((icone, _, _) in CATEGORIES) liste.add(icone)
        return liste
    }

    /** Centres verticaux des 4 boutons de la colonne de droite */
    private fun boutonsEmoji(): List<Float> {
        val zone = height - barre
        return (0 until 4).map { barre + zone * (it + 0.5f) / 4f }
    }

    private var emojiY0 = 0f
    private var emojiX0 = 0f
    private var emojiDernierY = 0f
    private var emojiDefile = false

    private fun toucherEmojis(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                emojiX0 = x
                emojiY0 = y
                emojiDernierY = y
                emojiDefile = false
                if (x > colonneDroite() && y > barre) {
                    val i = ((y - barre) / ((height - barre) / 4f)).toInt().coerceIn(0, 3)
                    if (i == 1) demarrerRepetition(420, 55) { service.supprimer() }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (x < colonneDroite() && y > barre && (emojiDefile || abs(y - emojiY0) > 8 * dp)) {
                    emojiDefile = true
                    defilement += emojiDernierY - y
                    emojiDernierY = y
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val repete = aRepete && repetition != null
                arreterRepetition()
                if (emojiDefile) return true
                if (vibrationsOk()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (y < barre) {
                    // onglet → aller à la catégorie
                    val n = onglets().size
                    val i = (x / (width / n.toFloat())).toInt().coerceIn(0, n - 1)
                    construireEmojis()
                    defilement = debutCategorie.getOrNull(i) ?: 0f
                } else if (x > colonneDroite()) {
                    when (((y - barre) / ((height - barre) / 4f)).toInt().coerceIn(0, 3)) {
                        0 -> service.fermerEmojis()
                        1 -> if (!repete) service.supprimer()
                        2 -> service.caractere(" ")
                        3 -> service.entree()
                    }
                } else {
                    val cell = celluleEmoji()
                    val yy = y - barre + defilement
                    val ligne = lignesEmoji.firstOrNull { yy >= it.y && yy < it.y + it.h }
                    val col = (x / cell).toInt()
                    ligne?.emojis?.getOrNull(col)?.let { service.emoji(it) }
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> arreterRepetition()
        }
        return true
    }

    private fun vibrationsOk() = service.vibrationsActives

    // ---------------------------------------------------------------- toucher (lettres, chiffres, symboles)

    private class Doigt(val id: Int, val x0: Float, val y0: Float, val touche: Touche?) {
        var curseur = false
        var pas = 0
        var barre = -1
        var efface = false
        var debutEfface = 0L
        var remet = false
        var base = 0
        var bonus = 0
        var bord: Runnable? = null
        var popup: List<String>? = null
        var choix = 0
        var defaut = 0
        var appuiLong: Runnable? = null
    }

    private val doigts = HashMap<Int, Doigt>()
    private val pressees = HashSet<Touche>()
    private val handler = Handler(Looper.getMainLooper())
    private var repetition: Runnable? = null
    private var aRepete = false

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (service.couche == 3 && doigts.isEmpty()) return toucherEmojis(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val x = e.getX(i)
                val y = e.getY(i)
                val id = e.getPointerId(i)
                if (y < barre) {
                    doigts[id] = Doigt(id, x, y, null).also { it.barre = slot(x) }
                    return true
                }
                val t = trouver(x, y)
                val d = Doigt(id, x, y, t)
                doigts[id] = d
                if (t != null) {
                    pressees.add(t)
                    if (vibrationsOk()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (t.type == Type.SUPPR) demarrerRepetition(420, 55) { service.supprimer() }
                    if (t.type == Type.CAR && t.bis.isNotEmpty()) {
                        // Maintenir = le « bis »
                        val run = Runnable {
                            if (doigts[id] === d && !d.efface) {
                                d.popup = t.bis
                                d.defaut = t.bisDefaut
                                d.choix = t.bisDefaut
                                if (vibrationsOk()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                                invalidate()
                            }
                        }
                        d.appuiLong = run
                        handler.postDelayed(run, 330)
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val d = doigts[e.getPointerId(i)] ?: continue
                    val t = d.touche ?: continue
                    bouger(d, t, e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                val d = doigts.remove(e.getPointerId(i))
                if (d != null) {
                    d.appuiLong?.let { handler.removeCallbacks(it) }
                    relacher(d, e.getX(i), e.getY(i))
                }
                if (e.actionMasked == MotionEvent.ACTION_UP) toutLacher()
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                toutLacher()
                invalidate()
            }
        }
        return true
    }

    private fun toutLacher() {
        for (d in doigts.values) {
            d.appuiLong?.let { handler.removeCallbacks(it) }
            finGlisse(d)
        }
        doigts.clear()
        pressees.clear()
        arreterRepetition()
    }

    private fun bouger(d: Doigt, t: Touche, x: Float, y: Float) {
        val dx = x - d.x0
        val dy = y - d.y0
        val seuil = w * 0.6f

        // Choix dans la bulle « bis »
        val popup = d.popup
        if (popup != null) {
            val (gauche, cell) = cellules(d, popup.size)
            val c = ((x - gauche) / cell).toInt().coerceIn(0, popup.size - 1)
            if (c != d.choix) {
                d.choix = c
                invalidate()
            }
            return
        }

        // Maintenir l'espace et glisser = déplacer le curseur
        if (t.type == Type.ESPACE && curseurPermis(t)) {
            if (!d.curseur && abs(dx) > w * 0.5f) d.curseur = true
            if (d.curseur) {
                val pas = (dx / (w * 0.3f)).toInt()
                if (pas != d.pas) {
                    service.deplacerCurseur(pas - d.pas)
                    d.pas = pas
                }
            }
            return
        }

        if (abs(dx) > seuil * 0.5f || abs(dy) > seuil * 0.5f) {
            d.appuiLong?.let { handler.removeCallbacks(it) }
            d.appuiLong = null
        }

        // Glisser à gauche = effacer lettre par lettre ; glisser à droite = remettre lettre par lettre.
        // Comme un curseur : plus loin = plus de lettres, revenir en arrière = ça s'inverse.
        if (!d.efface && !d.remet && abs(dx) > seuil && abs(dx) > abs(dy)) {
            if (dx < 0) {
                d.efface = true
                service.effacementDebut()
            } else {
                d.remet = true
                service.remettreDebut()
            }
            pressees.remove(t)
            arreterRepetition()
            d.debutEfface = android.os.SystemClock.uptimeMillis()
            invalidate()
        }
        if (d.efface || d.remet) {
            val sens = if (d.efface) -dx else dx
            var n = maxOf(0, ((sens - seuil) / pasLettre()).toInt() + 1)
            // Un coup de balayage rapide = une seule lettre ; pour en faire plus, il faut glisser
            val ecoule = android.os.SystemClock.uptimeMillis() - d.debutEfface
            val nMax = 1 + maxOf(0L, (ecoule - 180L) / 45L).toInt()
            if (n > nMax) n = nMax
            d.base = n
            // Arrivé au bord de l'écran : ça continue tout seul au même rythme
            val auBord = if (d.efface) x < w * 0.55f else x > width - w * 0.55f
            if (auBord) demarrerBord(d) else arreterBord(d)
            appliquerGlisse(d)
        }
    }

    /** Distance à glisser pour une lettre, selon le réglage lente / moyenne / rapide */
    private fun pasLettre(): Float = when (service.vitesseEffacement) {
        0 -> w * 0.65f
        2 -> w * 0.28f
        else -> w * 0.42f
    }

    /** Rythme quand le doigt est immobile au bord (ms par lettre) */
    private fun rythmeBord(): Long = when (service.vitesseEffacement) {
        0 -> 260L
        2 -> 100L
        else -> 170L
    }

    private fun appliquerGlisse(d: Doigt) {
        val total = maxOf(0, d.base + d.bonus)
        if (d.efface) service.effacementAller(total) else service.remettreAller(total)
    }

    private fun demarrerBord(d: Doigt) {
        if (d.bord != null) return
        val run = object : Runnable {
            override fun run() {
                d.bonus++
                appliquerGlisse(d)
                handler.postDelayed(this, rythmeBord())
            }
        }
        d.bord = run
        handler.postDelayed(run, rythmeBord())
    }

    private fun arreterBord(d: Doigt) {
        d.bord?.let { handler.removeCallbacks(it) }
        d.bord = null
    }

    private fun finGlisse(d: Doigt) {
        arreterBord(d)
        if (d.efface) service.effacementFin()
        if (d.remet) service.remettreFin()
    }

    /** Réglage : 0 = les deux espaces, 1 = espace de gauche, 2 = espace de droite, 3 = aucun */
    private fun curseurPermis(t: Touche): Boolean = when (service.curseurEspace) {
        1 -> t.haut == "g"
        2 -> t.haut == "d"
        3 -> false
        else -> true
    }

    /** -2 = bouton correction ; sinon numéro de la proposition */
    private fun slot(x: Float): Int {
        val b = boutonCorr()
        if (x < b) return -2
        return ((x - b) / ((width - b) / NB_PROPOSITIONS.toFloat())).toInt().coerceIn(0, NB_PROPOSITIONS - 1)
    }

    private fun relacher(d: Doigt, x: Float, y: Float) {
        if (d.barre != -1) {
            if (y < barre && slot(x) == d.barre) {
                if (d.barre == -2) service.basculerCorrection() else service.choisirSuggestion(d.barre)
            }
            return
        }
        val t = d.touche ?: return
        pressees.remove(t)
        if (d.efface || d.remet) {
            finGlisse(d)
            return
        }
        d.popup?.let { p ->
            service.caractere(p[d.choix.coerceIn(0, p.size - 1)])
            return
        }
        val dx = x - d.x0
        val dy = y - d.y0
        val seuil = w * 0.6f
        val horizontal = abs(dx) > seuil && abs(dx) > abs(dy)
        val vertical = abs(dy) > seuil && abs(dy) > abs(dx)

        when (t.type) {
            Type.ESPACE -> if (!d.curseur) {
                service.caractere(" ")
            }
            Type.SUPPR -> {
                val repete = aRepete
                arreterRepetition()
                if (!repete) service.supprimer()
            }
            else -> {
                if (horizontal) return
                when (t.type) {
                    Type.CAR -> {
                        val estLettre = t.haut.length == 1 && t.haut[0].isLetter()
                        when {
                            // Glisser vers le haut : zone claire, ou majuscule pour une lettre
                            vertical && dy < 0 && t.clair.isNotEmpty() -> service.caractere(t.clair)
                            vertical && dy < 0 -> service.caractere(t.haut, casse = 1)
                            // Glisser vers le bas : minuscule pour une lettre
                            vertical && estLettre -> service.caractere(t.haut, casse = -1)
                            else -> service.caractere(t.haut)
                        }
                    }
                    Type.SHIFT -> service.basculerShift()
                    Type.ENTREE -> service.entree()
                    Type.COUCHE -> if (vertical && dy < 0) service.coucheHaut() else service.basculerCouche()
                    Type.ACTION -> service.action(ACTIONS.indexOf(t.haut))
                    Type.EMOJI -> service.emoji(emojiRapide(t.haut.toInt()))
                    else -> {}
                }
            }
        }
    }

    private fun demarrerRepetition(premier: Long, intervalle: Long, action: () -> Unit) {
        arreterRepetition()
        aRepete = false
        val run = object : Runnable {
            override fun run() {
                aRepete = true
                action()
                handler.postDelayed(this, intervalle)
            }
        }
        repetition = run
        handler.postDelayed(run, premier)
    }

    private fun arreterRepetition() {
        repetition?.let { handler.removeCallbacks(it) }
        repetition = null
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        toutLacher()
    }
}
