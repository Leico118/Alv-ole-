plugins {
    id("com.android.application") version "8.7.3"
    id("org.jetbrains.kotlin.android") version "2.1.0"
}

android {
    namespace = "ch.leico.alveole"
    compileSdk = 35

    defaultConfig {
        applicationId = "ch.leico.alveole"
        minSdk = 26
        targetSdk = 34
        versionCode = 15
        versionName = "0.15"
    }

    // Clé fixe : les mises à jour s'installent par-dessus sans perdre les mots appris
    signingConfigs {
        create("perso") {
            storeFile = file("alveole.keystore")
            storePassword = "alveole"
            keyAlias = "alveole"
            keyPassword = "alveole"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("perso")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

// ---------------------------------------------------------------------------
// Suites de mots (contexte) : construites à la compilation à partir de vraies
// phrases françaises (Tatoeba, licence libre). Le téléphone n'a jamais besoin d'Internet.
val bigrammes by tasks.registering {
    val sortie = file("src/main/assets/bigrammes.txt")
    outputs.file(sortie)
    doLast {
        sortie.parentFile.mkdirs()
        try {
            val tmp = java.io.File(temporaryDir, "phrases.txt")
            val cmd = "curl -fsSL https://downloads.tatoeba.org/exports/per_language/fra/fra_sentences.tsv.bz2 | bzip2 -dc | cut -f3 > \"" + tmp.absolutePath + "\""
            val p = ProcessBuilder("bash", "-c", cmd).redirectErrorStream(true).start()
            p.inputStream.bufferedReader().readText()
            p.waitFor()
            val compte = HashMap<String, HashMap<String, Int>>()
            val motRegex = Regex("[\\p{L}'’-]+")
            var phrases = 0
            tmp.forEachLine { ligne ->
                phrases++
                var prec = "^"
                for (m in motRegex.findAll(ligne.lowercase().replace('’', '\''))) {
                    val w = m.value.trim('-', '\'')
                    if (w.isEmpty()) continue
                    val suiv = compte.getOrPut(prec) { HashMap() }
                    suiv[w] = (suiv[w] ?: 0) + 1
                    prec = w
                }
            }
            val sb = StringBuilder()
            var n = 0
            for ((a, suiv) in compte) {
                val total = suiv.values.sum()
                if (total < 8) continue
                val meilleurs = suiv.entries.filter { it.value >= 2 }.sortedByDescending { it.value }.take(10)
                if (meilleurs.isEmpty()) continue
                sb.append(a).append(" * ").append(total).append('\n')
                for (e in meilleurs) {
                    sb.append(a).append(' ').append(e.key).append(' ').append(e.value).append('\n')
                    n++
                }
            }
            sortie.writeText(sb.toString())
            println("Phrases lues : " + phrases + " ; suites de mots gardées : " + n)
        } catch (e: Exception) {
            println("Suites de mots indisponibles : " + e)
            sortie.writeText("")
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(bigrammes) }
