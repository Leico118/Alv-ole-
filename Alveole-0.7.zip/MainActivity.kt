package ch.leico.alveole

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val prefs = getSharedPreferences("alveole", Context.MODE_PRIVATE)
        val fond = Color.parseColor("#0E0E0E")

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (48 * dp).toInt(), (20 * dp).toInt(), (24 * dp).toInt())
            setBackgroundColor(fond)
        }

        fun texte(s: String, taille: Float, couleur: Int = Color.WHITE) = TextView(this).apply {
            text = s
            textSize = taille
            setTextColor(couleur)
            setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
        }

        fun bouton(s: String, action: () -> Unit) = Button(this).apply {
            text = s
            setAllCaps(false)
            setOnClickListener { action() }
        }

        fun interrupteur(s: String, cle: String) = Switch(this).apply {
            text = s
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean(cle, true)
            setPadding(0, (12 * dp).toInt(), 0, (12 * dp).toInt())
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(cle, v).apply() }
        }

        col.addView(texte("Alvéole", 30f))
        col.addView(texte("Ton clavier en nid d'abeille. L'appli n'a pas la permission Internet : rien de ce que tu tapes ne peut quitter ton téléphone.", 15f, Color.LTGRAY))
        // Vérification : le dictionnaire est-il bien chargé ?
        val etat = texte("Dictionnaire : chargement…", 14f, Color.LTGRAY)
        col.addView(etat)
        val correcteur = Correcteur.obtenir(this)
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.post(object : Runnable {
            override fun run() {
                if (correcteur.pret) {
                    val n = correcteur.nbMots
                    etat.text = if (n > 1000) "Dictionnaire : $n mots chargés ✓"
                    else "⚠ Dictionnaire vide ($n mots) : la compilation n'a pas téléchargé le dictionnaire"
                } else handler.postDelayed(this, 300)
            }
        })
        col.addView(bouton("1. Activer Alvéole") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        col.addView(bouton("2. Choisir Alvéole comme clavier") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        col.addView(interrupteur("Correction automatique", "correction"))
        col.addView(interrupteur("Raccourci « . » (double espace = point)", "point"))
        col.addView(interrupteur("Vibrations", "vibrations"))
        col.addView(EditText(this).apply {
            hint = "Zone de test : tape ici"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            minLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        })
        col.addView(texte(
            "Gestes\n" +
                "• Glisser à gauche : effacer lettre par lettre (plus loin = plus de lettres, reviens vers la droite pour les remettre)\n" +
                "• Glisser à droite : remettre ce qui vient d'être effacé\n" +
                "• Glisser une lettre vers le haut : majuscule ; vers le bas : minuscule\n" +
                "• Appui long sur une lettre : accents (é, è, ê, à, ç…) ; sur « . » : « : ; » ; sur « ? » : « \" ' »\n" +
                "• Touches à deux couleurs : appui = zone foncée, glisser en haut = zone claire, maintenir = le petit caractère en plus\n" +
                "• Touche 123 : glisser en haut = emojis (depuis les lettres) ou symboles spéciaux (depuis les chiffres)\n" +
                "• Maintenir un espace et glisser : déplacer le curseur\n" +
                "• Double espace : point\n" +
                "• Retour arrière juste après une correction : l'annuler (et si tu gardes ton mot, il est appris)\n" +
                "• Toucher ton mot dans la barre du haut : il est appris",
            14f, Color.LTGRAY
        ))
        col.addView(bouton("Oublier les mots et habitudes appris") {
            Correcteur.obtenir(this).oublierTout()
            Toast.makeText(this, "Mots et habitudes appris effacés", Toast.LENGTH_SHORT).show()
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(fond)
            addView(col)
        })
    }
}
