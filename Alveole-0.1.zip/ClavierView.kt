package ch.leico.alveole

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@SuppressLint("ViewConstructor")
class ClavierView(context: Context, private val service: ClavierService) : View(context) {

    enum class Type { CAR, ESPACE, SHIFT, SUPPR, ENTREE, COUCHE, PONCT }

    class Touche(
        val type: Type,
        val haut: String = "",
        val bas: String = "",
        val altHaut: String = "",
        val altBas: String = ""
    ) {
        var cx = 0f
        var cy = 0f
        val forme = Path()
    }

    class Couche(val rangees: List<List<Touche>>, avecShift: Boolean) {
        val gauche: Touche? = if (avecShift) Touche(Type.SHIFT) else null
        val droite = Touche(Type.SUPPR)
        val toutes: List<Touche> = rangees.flatten() + listOfNotNull(gauche, droite)
    }

    companion object {
        private val SQRT3 = sqrt(3f)
        private val ACCENTS = mapOf(
            "a" to "à", "e" to "é", "i" to "î", "o" to "ô", "u" to "ù",
            "c" to "ç", "n" to "ñ", "y" to "ÿ"
        )

        private fun car(s: String) = Touche(Type.CAR, s)
        private fun rangee(s: String) = s.split(' ').map { car(it) }
        private fun ponctGauche() = Touche(Type.PONCT, ",", ".", ";", ":")
        private fun ponctDroite() = Touche(Type.PONCT, "!", "?", "\"", "'")
    }

    // Disposition copiée de ta capture (nid d'abeille, 5 rangées)
    private val lettres = Couche(
        listOf(
            rangee("w e t z i o"),
            rangee("q a r g u l p"),
            listOf(ponctGauche(), Touche(Type.ESPACE), car("f"), car("h"), Touche(Type.ESPACE), ponctDroite()),
            rangee("y s d n m j k"),
            rangee("x c v b") + listOf(Touche(Type.COUCHE, "123"), Touche(Type.ENTREE))
        ),
        avecShift = true
    )

    private val symboles = Couche(
        listOf(
            rangee("1 2 3 4 5 6"),
            rangee("7 8 9 0 @ # €"),
            listOf(ponctGauche(), Touche(Type.ESPACE), car("-"), car("/"), Touche(Type.ESPACE), ponctDroite()),
            rangee("( ) + = * & %"),
            rangee("_ $ < >") + listOf(Touche(Type.COUCHE, "ABC"), Touche(Type.ENTREE))
        ),
        avecShift = false
    )

    private val dp = resources.displayMetrics.density
    private val barre = 46 * dp
    private val marge = 6 * dp
    private var w = 0f
    private var r = 0f
    private var x0 = 0f

    // Couleurs (thème noir)
    private val cFond = Color.parseColor("#0E0E0E")
    private val cTouche = Color.parseColor("#3A3A3C")
    private val cPresse = Color.parseColor("#5C5C60")
    private val cPonctHaut = Color.parseColor("#4A4A4D")
    private val cEspace = Color.parseColor("#6B6B6E")
    private val cEspacePresse = Color.parseColor("#8E8E92")
    private val cBleu = Color.parseColor("#3D6CF0")
    private val cBleuPresse = Color.parseColor("#6A8EF5")
    private val cGris = Color.parseColor("#B0B0B4")

    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pTexte = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val pTrait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val pBarre = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
    }
    private val pSep = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#555558")
        strokeWidth = 1.5f * dp
    }
    private val normal = Typeface.create("sans-serif", Typeface.NORMAL)
    private val gras = Typeface.create("sans-serif", Typeface.BOLD)

    // ---------------------------------------------------------------- géométrie

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val largeur = MeasureSpec.getSize(widthMeasureSpec)
        calculer(largeur.toFloat(), resources.displayMetrics.heightPixels.toFloat())
        setMeasuredDimension(largeur, (barre + 2 * marge + 8 * r).toInt())
    }

    private fun calculer(largeur: Float, ecran: Float) {
        val rMax = (ecran * 0.42f - barre - 2 * marge) / 8f
        r = minOf(largeur / 7f / SQRT3, rMax)
        w = r * SQRT3
        x0 = (largeur - 7 * w) / 2f
        pFill.pathEffect = CornerPathEffect(r * 0.2f)
        pTrait.strokeWidth = r * 0.075f
        placer(lettres)
        placer(symboles)
    }

    private fun placer(c: Couche) {
        c.rangees.forEachIndexed { i, rangee ->
            val y = barre + marge + r + i * 1.5f * r
            val decale = rangee.size < 7
            rangee.forEachIndexed { j, t ->
                t.cx = x0 + if (decale) w * (j + 1) else w * (j + 0.5f)
                t.cy = y
                hexagone(t.forme, t.cx, t.cy, r * 0.94f)
            }
        }
        val y2 = barre + marge + r + 3f * r
        c.gauche?.let {
            it.cx = x0 + w * 0.3f
            it.cy = y2
        }
        c.droite.cx = x0 + 7 * w - w * 0.3f
        c.droite.cy = y2
    }

    private fun hexagone(p: Path, cx: Float, cy: Float, rr: Float) {
        p.reset()
        for (k in 0 until 6) {
            val a = Math.toRadians(60.0 * k - 90.0)
            val x = cx + rr * cos(a).toFloat()
            val y = cy + rr * sin(a).toFloat()
            if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun couche(): Couche = if (service.symboles) symboles else lettres

    private fun trouver(x: Float, y: Float): Touche? {
        var meilleure: Touche? = null
        var dMin = Float.MAX_VALUE
        for (t in couche().toutes) {
            val dx = x - t.cx
            val dy = y - t.cy
            val d = dx * dx + dy * dy
            if (d < dMin) {
                dMin = d
                meilleure = t
            }
        }
        return meilleure
    }

    // ---------------------------------------------------------------- dessin

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(cFond)
        dessinerBarre(canvas)
        for (t in couche().toutes) dessinerTouche(canvas, t)
    }

    private fun dessinerBarre(cv: Canvas) {
        val sugg = service.suggestions
        val l = width / 3f
        for (i in 0 until 3) {
            if (i > 0) cv.drawLine(l * i, barre * 0.28f, l * i, barre * 0.72f, pSep)
            val s = sugg.getOrNull(i) ?: continue
            pBarre.typeface = if (i == service.indexCorrection) gras else normal
            var taille = 18 * dp
            pBarre.textSize = taille
            while (pBarre.measureText(s) > l - 14 * dp && taille > 9 * dp) {
                taille -= dp
                pBarre.textSize = taille
            }
            val m = pBarre.fontMetrics
            cv.drawText(s, l * i + l / 2f, barre / 2f - (m.ascent + m.descent) / 2f, pBarre)
        }
    }

    private fun remplir(cv: Canvas, t: Touche, couleur: Int) {
        pFill.color = couleur
        cv.drawPath(t.forme, pFill)
    }

    private fun texte(cv: Canvas, s: String, x: Float, y: Float, taille: Float, couleur: Int) {
        if (s.isEmpty()) return
        pTexte.textSize = taille
        pTexte.color = couleur
        val m = pTexte.fontMetrics
        cv.drawText(s, x, y - (m.ascent + m.descent) / 2f, pTexte)
    }

    private fun dessinerTouche(cv: Canvas, t: Touche) {
        val presse = t in pressees
        when (t.type) {
            Type.CAR -> {
                remplir(cv, t, if (presse) cPresse else cTouche)
                val s = if (service.shift > 0 && !service.symboles) t.haut.uppercase() else t.haut
                texte(cv, s, t.cx, t.cy, r * 0.8f, Color.WHITE)
            }
            Type.ESPACE -> remplir(cv, t, if (presse) cEspacePresse else cEspace)
            Type.PONCT -> {
                remplir(cv, t, if (presse) cPresse else cTouche)
                if (!presse) {
                    cv.save()
                    cv.clipRect(t.cx - r, t.cy - r, t.cx + r, t.cy)
                    remplir(cv, t, cPonctHaut)
                    cv.restore()
                }
                texte(cv, t.haut, t.cx, t.cy - r * 0.42f, r * 0.6f, Color.WHITE)
                texte(cv, t.bas, t.cx, t.cy + r * 0.45f, r * 0.6f, Color.WHITE)
                texte(cv, t.altBas, t.cx + r * 0.42f, t.cy + r * 0.45f, r * 0.32f, cGris)
            }
            Type.ENTREE -> {
                remplir(cv, t, if (presse) cBleuPresse else cBleu)
                iconeEntree(cv, t.cx, t.cy)
            }
            Type.COUCHE -> {
                remplir(cv, t, if (presse) cPresse else cTouche)
                texte(cv, t.haut, t.cx, t.cy, r * 0.46f, Color.WHITE)
            }
            Type.SHIFT -> iconeShift(cv, t.cx, t.cy, presse)
            Type.SUPPR -> iconeSuppr(cv, t.cx, t.cy, presse)
        }
    }

    private fun halo(cv: Canvas, x: Float, y: Float) {
        pFill.color = cPresse
        cv.drawCircle(x, y, r * 0.5f, pFill)
    }

    private fun iconeShift(cv: Canvas, x: Float, y: Float, presse: Boolean) {
        if (presse) halo(cv, x, y)
        val s = r * 0.3f
        val p = Path().apply {
            moveTo(x, y - s)
            lineTo(x + s, y)
            lineTo(x + s * 0.45f, y)
            lineTo(x + s * 0.45f, y + s * 0.8f)
            lineTo(x - s * 0.45f, y + s * 0.8f)
            lineTo(x - s * 0.45f, y)
            lineTo(x - s, y)
            close()
        }
        if (service.shift > 0) {
            pFill.color = Color.WHITE
            cv.drawPath(p, pFill)
        } else {
            cv.drawPath(p, pTrait)
        }
        if (service.shift == 2) cv.drawLine(x - s * 0.6f, y + s * 1.3f, x + s * 0.6f, y + s * 1.3f, pTrait)
    }

    private fun iconeSuppr(cv: Canvas, x: Float, y: Float, presse: Boolean) {
        if (presse) halo(cv, x, y)
        val s = r * 0.3f
        val p = Path().apply {
            moveTo(x - s * 1.1f, y)
            lineTo(x - s * 0.45f, y - s * 0.7f)
            lineTo(x + s, y - s * 0.7f)
            lineTo(x + s, y + s * 0.7f)
            lineTo(x - s * 0.45f, y + s * 0.7f)
            close()
        }
        cv.drawPath(p, pTrait)
        cv.drawLine(x - s * 0.05f, y - s * 0.3f, x + s * 0.55f, y + s * 0.3f, pTrait)
        cv.drawLine(x - s * 0.05f, y + s * 0.3f, x + s * 0.55f, y - s * 0.3f, pTrait)
    }

    private fun iconeEntree(cv: Canvas, x: Float, y: Float) {
        val s = r * 0.32f
        val p = Path().apply {
            moveTo(x + s * 0.7f, y - s * 0.7f)
            lineTo(x + s * 0.7f, y + s * 0.25f)
            lineTo(x - s * 0.7f, y + s * 0.25f)
        }
        cv.drawPath(p, pTrait)
        cv.drawLine(x - s * 0.7f, y + s * 0.25f, x - s * 0.3f, y - s * 0.15f, pTrait)
        cv.drawLine(x - s * 0.7f, y + s * 0.25f, x - s * 0.3f, y + s * 0.65f, pTrait)
    }

    // ---------------------------------------------------------------- toucher

    private class Doigt(val x0: Float, val y0: Float, val touche: Touche?) {
        var curseur = false
        var pas = 0
        var barre = -1
    }

    private val doigts = HashMap<Int, Doigt>()
    private val pressees = HashSet<Touche>()
    private val handler = Handler(Looper.getMainLooper())
    private var repetition: Runnable? = null
    private var aRepete = false

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val x = e.getX(i)
                val y = e.getY(i)
                val id = e.getPointerId(i)
                if (y < barre) {
                    doigts[id] = Doigt(x, y, null).also { it.barre = slot(x) }
                    return true
                }
                val t = trouver(x, y)
                doigts[id] = Doigt(x, y, t)
                if (t != null) {
                    pressees.add(t)
                    if (service.vibrationsActives) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (t.type == Type.SUPPR) demarrerRepetition()
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val d = doigts[e.getPointerId(i)] ?: continue
                    if (d.touche?.type != Type.ESPACE) continue
                    // Glisser sur une barre d'espace = déplacer le curseur
                    val dx = e.getX(i) - d.x0
                    if (!d.curseur && abs(dx) > w * 0.5f) d.curseur = true
                    if (d.curseur) {
                        val pas = (dx / (w * 0.3f)).toInt()
                        if (pas != d.pas) {
                            service.deplacerCurseur(pas - d.pas)
                            d.pas = pas
                        }
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                val d = doigts.remove(e.getPointerId(i))
                if (d != null) relacher(d, e.getX(i), e.getY(i))
                if (e.actionMasked == MotionEvent.ACTION_UP) {
                    doigts.clear()
                    pressees.clear()
                    arreterRepetition()
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                doigts.clear()
                pressees.clear()
                arreterRepetition()
                invalidate()
            }
        }
        return true
    }

    private fun slot(x: Float): Int = (x / (width / 3f)).toInt().coerceIn(0, 2)

    private fun relacher(d: Doigt, x: Float, y: Float) {
        if (d.barre >= 0) {
            if (y < barre && slot(x) == d.barre) service.choisirSuggestion(d.barre)
            return
        }
        val t = d.touche ?: return
        pressees.remove(t)
        val dx = x - d.x0
        val dy = y - d.y0
        val seuil = w * 0.6f
        val horizontal = abs(dx) > seuil && abs(dx) > abs(dy)
        val vertical = abs(dy) > seuil && abs(dy) > abs(dx)

        when (t.type) {
            Type.ESPACE -> if (!d.curseur) service.caractere(" ")
            Type.SUPPR -> {
                val repete = aRepete
                arreterRepetition()
                if (!repete) {
                    if (horizontal && dx < 0) service.supprimerMot() else service.supprimer()
                }
            }
            else -> {
                if (horizontal) {
                    // Glisser à gauche = effacer le mot, à droite = le remettre
                    if (dx < 0) service.supprimerMot() else service.restaurerMot()
                    return
                }
                when (t.type) {
                    Type.CAR -> when {
                        vertical && dy < 0 -> service.caractere(t.haut, majForcee = true)
                        vertical -> service.caractere(ACCENTS[t.haut] ?: t.haut)
                        else -> service.caractere(t.haut)
                    }
                    Type.PONCT -> when {
                        vertical && dy < 0 -> service.caractere(t.altHaut)
                        vertical -> service.caractere(t.altBas)
                        d.y0 < t.cy -> service.caractere(t.haut)
                        else -> service.caractere(t.bas)
                    }
                    Type.SHIFT -> service.basculerShift()
                    Type.ENTREE -> service.entree()
                    Type.COUCHE -> service.basculerCouche()
                    else -> {}
                }
            }
        }
    }

    private fun demarrerRepetition() {
        arreterRepetition()
        aRepete = false
        val run = object : Runnable {
            override fun run() {
                aRepete = true
                service.supprimer()
                handler.postDelayed(this, 55)
            }
        }
        repetition = run
        handler.postDelayed(run, 420)
    }

    private fun arreterRepetition() {
        repetition?.let { handler.removeCallbacks(it) }
        repetition = null
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        arreterRepetition()
    }
}
