package ch.leico.alveole

import android.content.Context
import java.text.Normalizer
import java.util.TreeSet

/**
 * Correcteur 100 % hors ligne : dictionnaire français (+ argot) embarqué dans l'appli.
 * Rien n'est envoyé nulle part : l'appli n'a même pas la permission Internet.
 */
class Correcteur private constructor(context: Context) {

    private val appli = context.applicationContext
    private val prefs = appli.getSharedPreferences("alveole", Context.MODE_PRIVATE)

    @Volatile
    var pret = false
        private set

    private val freq = HashMap<String, Long>(150_000)
    private val parCle = HashMap<String, ArrayList<String>>(150_000)
    private val cles = TreeSet<String>()
    private val perso = HashSet<String>()
    private val voisins = HashMap<Char, Set<Char>>()

    companion object {
        private const val RATIO_ACCENT = 30L
        private const val RATIO_APOSTROPHE = 1000L
        private const val ALPHABET = "abcdefghijklmnopqrstuvwxyz"
        private val PREFIXES = listOf("jusqu", "lorsqu", "puisqu", "qu", "j", "l", "d", "n", "m", "t", "s", "c")
        private val UNE_LETTRE = setOf("a", "à", "y", "ô", "o")
        private val MARQUES = Regex("\\p{Mn}+")

        @Volatile
        private var instance: Correcteur? = null

        fun obtenir(context: Context): Correcteur =
            instance ?: synchronized(this) {
                instance ?: Correcteur(context).also {
                    instance = it
                    it.charger()
                }
            }

        /** Clé de recherche : minuscules, sans accents, sans apostrophes ni tirets. */
        fun cle(mot: String): String {
            val m = mot.lowercase().replace("œ", "oe").replace("æ", "ae")
            val n = Normalizer.normalize(m, Normalizer.Form.NFD).replace(MARQUES, "")
            return n.filter { it.isLetter() }
        }

        fun casse(modele: String, mot: String): String {
            val lettres = modele.filter { it.isLetter() }
            if (lettres.length > 1 && lettres.all { it.isUpperCase() }) return mot.uppercase()
            if (modele.firstOrNull()?.isUpperCase() == true) return mot.replaceFirstChar { it.uppercaseChar() }
            return mot
        }
    }

    // ---------------------------------------------------------------- chargement

    private fun charger() {
        Thread {
            try {
                construireVoisins()
                lire("fr.txt")
                lire("argot.txt")
                for (m in prefs.getStringSet("perso", emptySet()) ?: emptySet()) {
                    perso.add(m)
                    ajouter(m, 20_000L)
                }
                for (l in parCle.values) trier(l)
            } catch (e: Throwable) {
                // dictionnaire absent ou abîmé : le clavier marche quand même, sans correction
            }
            pret = true
        }.start()
    }

    private fun lire(nom: String) {
        try {
            appli.assets.open(nom).bufferedReader(Charsets.UTF_8).useLines { lignes ->
                for (ligne in lignes) {
                    val parts = ligne.trim().split(' ', '\t').filter { it.isNotEmpty() }
                    if (parts.isEmpty()) continue
                    val mot = parts[0].lowercase().replace('’', '\'')
                    val f = if (parts.size > 1) parts.last().toLongOrNull() ?: 5_000L else 5_000L
                    if (valide(mot)) ajouter(mot, f)
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun valide(m: String): Boolean {
        if (m.isEmpty() || m.length > 30) return false
        if (m.length == 1 && m !in UNE_LETTRE) return false
        if (m.first() == '\'' || m.last() == '\'' || m.first() == '-' || m.last() == '-') return false
        return m.all { it.isLetter() || it == '\'' || it == '-' }
    }

    private fun ajouter(mot: String, f: Long) {
        val ancien = freq[mot]
        if (ancien == null || f > ancien) freq[mot] = f
        val k = cle(mot)
        if (k.isEmpty()) return
        val l = parCle.getOrPut(k) { ArrayList(1) }
        if (mot !in l) l.add(mot)
        cles.add(k)
    }

    private fun trier(l: ArrayList<String>) {
        l.sortByDescending { freq[it] ?: 0L }
    }

    private fun f(m: String): Long = freq[m] ?: 0L

    /** Touches voisines dans la disposition en nid d'abeille (pour les fautes de frappe). */
    private fun construireVoisins() {
        val rangees = listOf("wetzio" to true, "qargulp" to false, "  fh  " to true, "ysdnmjk" to false, "xcvb" to true)
        val pos = ArrayList<Triple<Char, Float, Float>>()
        rangees.forEachIndexed { r, (lettres, decale) ->
            lettres.forEachIndexed { i, c ->
                if (c != ' ') pos.add(Triple(c, if (decale) i + 1f else i + 0.5f, r * 0.866f))
            }
        }
        for ((c, x, y) in pos) {
            val s = HashSet<Char>()
            for ((c2, x2, y2) in pos) {
                val dx = x - x2
                val dy = y - y2
                if (c2 != c && dx * dx + dy * dy < 1.21f) s.add(c2)
            }
            voisins[c] = s
        }
    }

    // ---------------------------------------------------------------- correction

    /**
     * Résout un mot sans deviner : accents (ete → été), apostrophes (jai → j'ai),
     * mots du dictionnaire. Renvoie null si le mot est inconnu.
     */
    fun strict(tape: String): Pair<String, Long>? {
        val t = tape.lowercase().replace('’', '\'')
        if (t in perso) return t to 20_000L
        val k = cle(t)
        if (k.isEmpty()) return null

        val variante = parCle[k]?.firstOrNull()
        val fv = if (variante != null) f(variante) else 0L
        val contr = contraction(k)
        val fe = freq[t]

        if (fe != null) {
            if (variante != null && variante != t && fv > fe * RATIO_ACCENT) return variante to fv
            if (contr != null && contr.second > fe * RATIO_APOSTROPHE) return contr
            return t to fe
        }
        if (variante != null && (contr == null || fv >= contr.second)) return variante to fv
        return contr
    }

    /** jai → j'ai, cest → c'est, quil → qu'il, jetais → j'étais, ny → n'y… */
    private fun contraction(k: String): Pair<String, Long>? {
        var res: Pair<String, Long>? = null
        for (p in PREFIXES) {
            if (!k.startsWith(p) || k.length <= p.length) continue
            val reste = k.substring(p.length)
            if (reste.length < 2 && reste != "y") continue
            if (reste[0] !in "aeiouyh") continue
            val mot = parCle[reste]?.firstOrNull() ?: continue
            if (mot.contains('\'')) continue
            val fr = f(mot) / 4
            if (res == null || fr > res.second) res = "$p'$mot" to fr
        }
        return res
    }

    fun estConnu(tape: String): Boolean = pret && strict(tape) != null

    /** Correction complète d'un mot validé (espace, ponctuation, entrée). */
    fun corriger(tape: String): String {
        if (!pret || tape.isEmpty()) return tape
        if (tape.any { it.isDigit() }) return tape
        strict(tape)?.let { return casse(tape, it.first) }
        val t = tape.lowercase().replace('’', '\'')
        if (cle(t).length <= 2) return tape
        val d = deviner(t) ?: return tape
        return casse(tape, d)
    }

    /** Correction légère pour la barre de suggestions (rapide, à chaque lettre). */
    fun corrigerRapide(tape: String): String {
        if (!pret || tape.isEmpty() || tape.any { it.isDigit() }) return tape
        val s = strict(tape) ?: return tape
        return casse(tape, s.first)
    }

    private fun deviner(t: String): String? {
        val k = cle(t)
        var meilleur: String? = null
        var score = 0.0
        fun proposer(m: String, s: Double) {
            if (s > score) {
                score = s
                meilleur = m
            }
        }

        // 1 faute de frappe
        val e1 = editions(k)
        for ((c, poids) in e1) {
            parCle[c]?.firstOrNull()?.let { proposer(it, f(it) * poids) }
            contraction(c)?.let { proposer(it.first, it.second * poids) }
        }

        // 2 fautes (mots assez longs seulement)
        if (meilleur == null && k.length >= 5) {
            for ((c1, p1) in e1) {
                for ((c2, p2) in editions(c1)) {
                    val m = parCle[c2]?.firstOrNull() ?: continue
                    proposer(m, f(m) * p1 * p2 * 0.3)
                }
            }
        }

        // espace oublié : jesuis → je suis
        for (i in 1 until t.length) {
            val a = strict(t.substring(0, i)) ?: continue
            val b = strict(t.substring(i)) ?: continue
            val mini = minOf(a.second, b.second)
            if (mini >= 1_000L) proposer(a.first + " " + b.first, mini * 0.8)
        }
        return meilleur
    }

    private fun editions(k: String): HashMap<String, Double> {
        val r = HashMap<String, Double>()
        fun ajout(s: String, p: Double) {
            if (s.isNotEmpty() && (r[s] ?: 0.0) < p) r[s] = p
        }
        for (i in k.indices) {
            // lettre en trop (plus probable si doublée)
            ajout(k.removeRange(i, i + 1), if (i > 0 && k[i] == k[i - 1]) 0.7 else 0.5)
            // deux lettres inversées
            if (i + 1 < k.length) ajout(k.substring(0, i) + k[i + 1] + k[i] + k.substring(i + 2), 0.6)
            // mauvaise touche (voisine = très probable)
            val v = voisins[k[i]]
            for (c in ALPHABET) {
                if (c != k[i]) ajout(k.substring(0, i) + c + k.substring(i + 1), if (v != null && c in v) 0.6 else 0.12)
            }
        }
        // lettre oubliée
        for (i in 0..k.length) for (c in ALPHABET) ajout(k.substring(0, i) + c + k.substring(i), 0.4)
        return r
    }

    /**
     * Espace mal placé entre deux mots : « bonj our » → « bonjour », « bonjou rça » → « bonjour ça ».
     * Ne touche à rien si les deux mots tapés existent déjà.
     */
    fun corrigerPaire(o1: String, o2: String): String? {
        if (!pret || o1.isEmpty() || o2.isEmpty()) return null
        if (o1.any { it.isDigit() } || o2.any { it.isDigit() }) return null
        val c1 = strict(o1) != null
        val c2 = strict(o2) != null
        if (c1 && c2) return null
        strict(o1 + o2)?.let { return casse(o1, it.first) }
        for (d in 1..2) {
            if (o1.length > d) {
                val a = strict(o1.dropLast(d))
                val b = strict(o1.takeLast(d) + o2)
                if (a != null && b != null) return casse(o1, a.first) + " " + b.first
            }
            if (o2.length > d) {
                val a = strict(o1 + o2.take(d))
                val b = strict(o2.drop(d))
                if (a != null && b != null) return casse(o1, a.first) + " " + casse(o2.drop(d), b.first)
            }
        }
        return null
    }

    /** Mots qui commencent comme ce qui est tapé, du plus courant au moins courant. */
    fun suggestions(tape: String, max: Int): List<String> {
        if (!pret || tape.isEmpty()) return emptyList()
        val k = cle(tape)
        if (k.isEmpty()) return emptyList()
        val top = ArrayList<Pair<String, Long>>()
        for (c in cles.subSet(k, true, k + '￿', false)) {
            val m = parCle[c]?.firstOrNull() ?: continue
            val fm = f(m)
            if (top.size < max || fm > top.last().second) {
                top.add(m to fm)
                top.sortByDescending { it.second }
                if (top.size > max) top.removeAt(top.size - 1)
            }
        }
        return top.map { casse(tape, it.first) }
    }

    /** Le mot devient « connu » : il ne sera plus jamais corrigé. */
    fun apprendre(mot: String) {
        val m = mot.lowercase().replace('’', '\'')
        if (!valide(m)) return
        val s = HashSet(prefs.getStringSet("perso", emptySet()) ?: emptySet())
        s.add(m)
        prefs.edit().putStringSet("perso", s).apply()
        perso.add(m)
        if (pret) {
            ajouter(m, maxOf(f(m), 20_000L))
            parCle[cle(m)]?.let { trier(it) }
        }
    }

    fun oublierTout() {
        prefs.edit().remove("perso").apply()
        perso.clear()
    }
}
