package ch.leico.alveole

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class ClavierService : InputMethodService() {

    private lateinit var correcteur: Correcteur
    private var vue: ClavierView? = null
    private val mot = StringBuilder()

    private var corrigerActif = true
    private var vibrations = true
    private var pointRaccourci = true

    /** Mot précédent, validé par un espace : (tapé, affiché). Sert à corriger un espace mal placé. */
    private var precedent: Pair<String, String>? = null
    /** Dernière correction auto : (texte inséré, texte tapé). Retour arrière = annuler. */
    private var annulable: Pair<String, String>? = null
    /** Mot remis après annulation : s'il est validé tel quel, on l'apprend. */
    private var restaure: String? = null
    private var ignorerEspace = false
    private val supprimes = ArrayDeque<String>()
    private var dernierShift = 0L

    var shift = 0
        private set
    var symboles = false
        private set
    var suggestions: List<String> = emptyList()
        private set
    var indexCorrection = -1
        private set
    val vibrationsActives: Boolean
        get() = vibrations

    override fun onCreate() {
        super.onCreate()
        correcteur = Correcteur.obtenir(this)
    }

    override fun onCreateInputView(): View {
        val v = ClavierView(this, this)
        vue = v
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val prefs = getSharedPreferences("alveole", Context.MODE_PRIVATE)
        vibrations = prefs.getBoolean("vibrations", true)
        pointRaccourci = prefs.getBoolean("point", true)
        val classe = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        val sansCorrection = classe != InputType.TYPE_CLASS_TEXT ||
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        corrigerActif = prefs.getBoolean("correction", true) && !sansCorrection
        symboles = classe == InputType.TYPE_CLASS_NUMBER ||
            classe == InputType.TYPE_CLASS_PHONE ||
            classe == InputType.TYPE_CLASS_DATETIME
        mot.clear()
        precedent = null
        annulable = null
        restaure = null
        ignorerEspace = false
        supprimes.clear()
        shift = 0
        majAuto()
        majSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        mot.clear()
        suggestions = emptyList()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // L'utilisateur a touché ailleurs dans le texte : on abandonne le mot en cours.
        if (mot.isNotEmpty() && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            mot.clear()
            currentInputConnection?.finishComposingText()
            precedent = null
            annulable = null
            majSuggestions()
        }
    }

    // ---------------------------------------------------------------- saisie

    /** casse : 1 = majuscule forcée (glisser en haut), -1 = minuscule forcée (glisser en bas), 0 = auto */
    fun caractere(brut: String, casse: Int = 0) {
        val ic = currentInputConnection ?: return
        if (brut.isEmpty()) return
        var s = brut
        val estLettre = s.length == 1 && s[0].isLetter()
        if (estLettre) {
            val maj = casse == 1 || (casse == 0 && shift > 0)
            s = if (maj) s.uppercase() else s.lowercase()
        }
        val c = s[0]
        if (estLettre || ((c == '\'' || c == '-') && s.length == 1 && mot.isNotEmpty())) {
            ignorerEspace = false
            annulable = null
            mot.append(s)
            ic.setComposingText(mot, 1)
            if (estLettre && shift == 1) shift = 0
            majSuggestions()
            vue?.invalidate()
        } else {
            valider(s)
        }
    }

    /** Valide le mot en cours (corrigé) suivi du séparateur. */
    private fun valider(sep: String) {
        val ic = currentInputConnection ?: return

        if (mot.isEmpty()) {
            if (sep == " " && ignorerEspace) {
                ignorerEspace = false
                return
            }
            ignorerEspace = false
            precedent = null
            annulable = null
            // Raccourci « . » : double espace = point + espace
            if (sep == " " && pointRaccourci) {
                val avant = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                if (avant.length == 2 && avant[1] == ' ' && avant[0].isLetterOrDigit()) {
                    ic.beginBatchEdit()
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText(". ", 1)
                    ic.endBatchEdit()
                    finCommit()
                    return
                }
            }
            // « salut ,» → « salut, »
            if (sep == "," || sep == ".") {
                val avant = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
                if (avant.length == 2 && avant[1] == ' ' && avant[0].isLetter()) {
                    ic.beginBatchEdit()
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText("$sep ", 1)
                    ic.endBatchEdit()
                    ignorerEspace = true
                    finCommit()
                    return
                }
            }
            ic.commitText(sep, 1)
            finCommit()
            return
        }

        val orig = mot.toString()
        mot.clear()
        ignorerEspace = false

        // Mot remis après une annulation et validé tel quel : on l'apprend, sans corriger.
        if (restaure != null && restaure == orig) {
            correcteur.apprendre(orig)
            restaure = null
            ic.commitText(orig + sep, 1)
            annulable = null
            precedent = if (sep == " ") orig to orig else null
            finCommit()
            return
        }
        restaure = null

        // Espace mal placé avec le mot d'avant ?
        val p = precedent
        if (corrigerActif && p != null) {
            val attendu = p.second + " " + orig
            val avant = ic.getTextBeforeCursor(attendu.length, 0)?.toString()
            if (avant == attendu) {
                val paire = correcteur.corrigerPaire(p.first, orig)
                if (paire != null) {
                    ic.beginBatchEdit()
                    ic.setComposingText("", 1)
                    ic.deleteSurroundingText(p.second.length + 1, 0)
                    ic.commitText(paire + sep, 1)
                    ic.endBatchEdit()
                    annulable = (paire + sep) to (p.first + " " + orig)
                    precedent = null
                    finCommit()
                    return
                }
            }
        }

        val affiche = if (corrigerActif) correcteur.corriger(orig) else orig
        ic.commitText(affiche + sep, 1)
        annulable = if (affiche != orig) (affiche + sep) to orig else null
        precedent = if (sep == " ") orig to affiche else null
        finCommit()
    }

    fun supprimer() {
        val ic = currentInputConnection ?: return
        ignorerEspace = false
        if (mot.isNotEmpty()) {
            mot.deleteCharAt(mot.length - 1)
            ic.setComposingText(mot, 1)
            annulable = null
            majSuggestions()
            vue?.invalidate()
            return
        }
        val a = annulable
        annulable = null
        precedent = null
        if (a != null) {
            val avant = ic.getTextBeforeCursor(a.first.length, 0)?.toString()
            if (avant == a.first) {
                // Annuler la correction : on remet exactement ce qui avait été tapé.
                ic.beginBatchEdit()
                ic.deleteSurroundingText(a.first.length, 0)
                if (a.second.contains(' ')) {
                    ic.commitText(a.second, 1)
                } else {
                    mot.append(a.second)
                    ic.setComposingText(mot, 1)
                    restaure = a.second
                }
                ic.endBatchEdit()
                majSuggestions()
                vue?.invalidate()
                return
            }
        }
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        finCommit()
    }

    fun supprimerMot() {
        val ic = currentInputConnection ?: return
        annulable = null
        precedent = null
        ignorerEspace = false
        if (mot.isNotEmpty()) {
            garder(mot.toString())
            mot.clear()
            ic.setComposingText("", 1)
            finCommit()
            return
        }
        val avant = ic.getTextBeforeCursor(80, 0)?.toString() ?: return
        val m = Regex("\\S+\\s*$").find(avant) ?: Regex("\\s+$").find(avant) ?: return
        ic.deleteSurroundingText(m.value.length, 0)
        garder(m.value)
        finCommit()
    }

    private fun garder(s: String) {
        supprimes.addLast(s)
        if (supprimes.size > 30) supprimes.removeFirst()
    }

    fun restaurerMot() {
        val ic = currentInputConnection ?: return
        val s = supprimes.removeLastOrNull() ?: return
        if (mot.isNotEmpty()) {
            ic.finishComposingText()
            mot.clear()
        }
        ic.commitText(s, 1)
        annulable = null
        precedent = null
        finCommit()
    }

    fun deplacerCurseur(n: Int) {
        if (n == 0) return
        if (mot.isNotEmpty()) {
            currentInputConnection?.finishComposingText()
            mot.clear()
            majSuggestions()
        }
        precedent = null
        annulable = null
        val code = if (n < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        repeat(kotlin.math.abs(n)) { sendDownUpKeyEvents(code) }
    }

    fun entree() {
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo
        if (mot.isNotEmpty()) valider("")
        precedent = null
        annulable = null
        val options = info?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val pasAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (info != null && !pasAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendKeyChar('\n')
        }
        finCommit()
    }

    fun basculerShift() {
        val maintenant = System.currentTimeMillis()
        shift = when {
            shift == 2 -> 0
            shift == 1 && maintenant - dernierShift < 350 -> 2
            shift == 1 -> 0
            else -> 1
        }
        dernierShift = maintenant
        vue?.invalidate()
    }

    fun basculerCouche() {
        symboles = !symboles
        vue?.invalidate()
    }

    fun choisirSuggestion(i: Int) {
        val s = suggestions.getOrNull(i) ?: return
        val ic = currentInputConnection ?: return
        if (mot.isEmpty()) return
        val orig = mot.toString()
        mot.clear()
        ic.commitText("$s ", 1)
        // Choisir exactement ce qu'on a tapé = « ce mot est correct, retiens-le »
        if (s == orig && i != indexCorrection) correcteur.apprendre(orig)
        annulable = null
        precedent = if (s.contains(' ')) null else s to s
        restaure = null
        finCommit()
    }

    // ---------------------------------------------------------------- état

    private fun finCommit() {
        majAuto()
        majSuggestions()
        vue?.invalidate()
    }

    /** Majuscule automatique en début de phrase. */
    private fun majAuto() {
        if (shift == 2 || mot.isNotEmpty()) return
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val modes = if (corrigerActif) InputType.TYPE_TEXT_FLAG_CAP_SENTENCES else info.inputType
        shift = if (modes != 0 && ic.getCursorCapsMode(modes) != 0) 1 else 0
    }

    private fun majSuggestions() {
        indexCorrection = -1
        if (mot.isEmpty() || !corrigerActif || !correcteur.pret) {
            suggestions = emptyList()
            return
        }
        val orig = mot.toString()
        val liste = ArrayList<String>()
        val corr = correcteur.corrigerRapide(orig)
        if (corr != orig) {
            liste.add(orig)
            liste.add(corr)
            indexCorrection = 1
        }
        for (s in correcteur.suggestions(orig, 4)) {
            if (liste.size >= 3) break
            if (s != orig && s !in liste) liste.add(s)
        }
        if (indexCorrection < 0 && liste.size >= 2) {
            // la meilleure proposition au milieu, comme d'habitude
            val premier = liste.removeAt(0)
            liste.add(1, premier)
            indexCorrection = 1
        }
        suggestions = liste
    }
}
